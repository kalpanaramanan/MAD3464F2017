/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExceptionHandling;

/**
 *
 * @author macstudent
 */
public class NegativeStartingBalanceException extends ArithmeticException {

    public NegativeStartingBalanceException() {
        super("Error: Negative starting balance");
    }

    public NegativeStartingBalanceException(double amount) {
        super("Error: Negative starting balance " + amount);
    }

    public NegativeStartingBalanceException(String message) {
        super(message);
    }
}
