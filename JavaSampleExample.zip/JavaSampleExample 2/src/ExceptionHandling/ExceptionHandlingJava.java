/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExceptionHandling;

/**
 *
 * @author macstudent
 */
public class ExceptionHandlingJava {

    public static void main(String[] args) {
        int a, b, c;
        a = 10;
        b = 0;
        char cChar[] = new char[6];

        System.out.println("First line ");

        /* try {
            c = a / b;
            System.out.println("Value of c: " + c);

            cChar[0] = 'A';
            cChar[1] = 'B';
            cChar[2] = 'C';
            cChar[3] = 'D';
            cChar[4] = 'E';
            cChar[5] = 'F';

            //System.out.println(" Character " + Arrays.toString(cChar));
            int abc = Integer.parseInt("10");
            if (a == 0) {
                throw new ArithmeticException("I fired AE");
            }

        } catch (ArithmeticException ae) {
            System.out.println("Arithmetic Exception - Number cannot be divide by Zero");
        } catch (ArrayIndexOutOfBoundsException are) {
            System.out.println("Exception Class- ArrayIndexOutOfBoundsException " + are.getMessage());
        } catch (Exception e) {
            System.out.println(e.toString());
        } finally {
            System.out.println("End");
        }*/

 /* ExceptionClassDemo demo  = new ExceptionClassDemo();
        try {
            System.out.println("Get my Name : " + demo.getMyName());
        } catch (IOException ex) {
           System.out.println(ex.getMessage());
        }finally {
            System.out.println("I am in finally block");
        }*/
        double balance = -1;
        if (balance < 0) {
            try {
                //throw new NegativeStartingBalanceException();
                //throw new NegativeStartingBalanceException(balance);
                throw new NegativeStartingBalanceException("Check your balance " + balance);
            } catch (NegativeStartingBalanceException ex) {
                System.out.println(ex.getMessage());
            }
        }

    }

}
