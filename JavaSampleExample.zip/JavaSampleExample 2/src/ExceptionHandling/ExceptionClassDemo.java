/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExceptionHandling;

import java.io.IOException;

/**
 *
 * @author macstudent
 */
public class ExceptionClassDemo {

    public String getMyName() throws IOException{
        String s = "Kalpana";
        return s;
    }
}
