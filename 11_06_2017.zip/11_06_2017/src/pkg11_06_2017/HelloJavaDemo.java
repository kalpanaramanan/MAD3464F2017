/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_06_2017;

/**
 *
 * @author Kalpana Ramanan
 */
public class HelloJavaDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Welcome to Java Programming");
        HelloJavaDemo helloJavaDemo = new HelloJavaDemo();
        helloJavaDemo.greet("Kalpana");
        greet(26);
        //helloJavaDemo.greet(new String[]{"Sai Praveen", "Kalpana", "Omika", "Richard"});
        helloJavaDemo.greet("Sai Praveen", "Kalpana", "Omika", "Richard"); // usgage of ... dot (you no need to decalre a string array)
    }

    void greet(String name) {
        System.out.println("Welcome , " + name);
    }

    static void greet(int age) {
        System.out.println("your age is," + age);
    }

    void greet(String... names) {
        //System.out.println("Welcome , " + names);
        for (String name : names) {
            System.out.println("Welcome, " + name);
        }
    }
}
