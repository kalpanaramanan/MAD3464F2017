/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_06_2017;

/**
 *
 * @author Kalpana Ramanan
 */
public class AccessStudent {

    public static void main(String[] args) {

        int[] markArray = new int[]{30, 40, 50};
        int total = Student.calculateTotal(markArray);

        Student student = new Student(1, "Kalpana", markArray, total);

        System.out.println(student.toString());
        student.setData();
        System.out.println("Student Details : "+student.getData());
    }
}
