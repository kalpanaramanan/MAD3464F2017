/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_06_2017;

import java.util.Arrays;

/**
 *
 * @author macstudent
 */
public class Student {

    private int studentID;
    private String studentName;
    private int[] marks;
    private int total;

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int[] getMarks() {
        return marks;
    }

    public void setMarks(int[] marks) {
        this.marks = marks;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Student{" + "studentID=" + studentID + ", studentName=" + studentName + ", marks=" + Arrays.toString(marks) + ", total=" + total + '}';
    }

    public Student(int studentID, String studentName, int[] marks, int total) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.marks = marks;
        this.total = total;
    }

    static int calculateTotal(int[] marks) {
        int sum = 0;
        for (int i = 0; i < marks.length; i++) {
            sum += marks[i];
        }
        return sum;
    }

    public String getData() {
        return "Student{" + "studentID=" + studentID + ", studentName=" + studentName + ", marks=" + Arrays.toString(marks) + ", total=" + total + '}';
    }

    public void setData() {
        studentID = 2;
        studentName = "Sai Praveen";
        marks = new int[]{20, 20, 20, 30};
        total = calculateTotal(marks);
    }

}
