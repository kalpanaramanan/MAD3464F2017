package com.lambton.magicalcardgame;

import java.util.Arrays;
import java.util.Locale;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Kalpana Ramanan
 */
public class StringTools {

    public static void main(String[] args) {

        String reverseData = reverseAString("Lambton");
        System.out.println(" Reverse a String :" + reverseData);

        String initialData = intials("kalpana ramanan Praveen");
        System.out.println("Initials of String :" + initialData);

        String mostData = mostFrequent("Kalpppppana");
        System.out.println("most Frequent of String :" + mostData);

        String replaceData = replaceSubString("the dog jumped over the fence", "the", "that");
        System.out.println("replaceData  of String :" + replaceData);
        
        int binaryToDecimal = binaryToDecimal("111111");
        System.out.println("replaceData  of String :" + binaryToDecimal);

    }
    
    static public int binaryToDecimal(String s){
        int decimalValue = Integer.parseInt(s, 2);
        return decimalValue;
    }

    static public String reverseAString(String inputString) {

        String str = "";

        char[] aChar = inputString.toCharArray();
        for (int i = aChar.length - 1; i >= 0; i--) {
            str += aChar[i];
        }

        return str;
    }

    static public String intials(String inputString) {

        String aStr[] = new String[]{};

        for (int i = 0; i < 3; i++) {
            aStr = inputString.split(" ");
        }
        System.out.println(Arrays.toString(inputString.split(" ")));

        String a = aStr[0].charAt(0) + ".";
        String b = aStr[1].charAt(0) + ".";
        String c = aStr[2].charAt(0) + " ";

        String str = a.toUpperCase() + b.toUpperCase() + aStr[2];

        return str;
    }

    static String mostFrequent(String inputString) {

        char aChar[] = inputString.toCharArray();
        int count = 0;
        String str = null;
        int previousCount = 0;
        for (int i = 0; i < aChar.length; i++) {

            for (int j = 0; j < aChar.length; j++) {
                if (aChar[i] == aChar[j]) {
                    count += 1;
                    str = aChar[i] + " ";
                }

            }
            System.out.println(aChar[i] +" <==> "  + count);
            count = 0;

        }
        return str;
    }

    static String replaceSubString(String s1, String s2, String s3) {
        String str = " ";
        String aStr[] = null;
        for (int i = 0; i < 6; i++) {
            aStr = s1.split(" ");
            if (aStr[i].equals(s2)) {
                str += aStr[i].replace(aStr[i], s3);
            } else {
                str += " " + aStr[i] + " ";
            }

        }
        return str;
    }

}
