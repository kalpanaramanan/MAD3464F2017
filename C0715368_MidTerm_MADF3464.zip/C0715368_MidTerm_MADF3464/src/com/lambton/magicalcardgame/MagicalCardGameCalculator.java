/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lambton.magicalcardgame;

/**
 *
 * @author Kalpana Ramanan
 */
public class MagicalCardGameCalculator implements IMagicalCardGameCalculator {

    @Override
    public String[][] getFirstShuffleResult(MagicalCardGameModel magicalCardGameModel) {

        magicalCardGameModel.firstShuffle =   new String[][]{{"A", "4", "3"},
        {"K", "7", "2"},
        {"5", "9", "8"}
        };

        switch (magicalCardGameModel.firstShuffleColPos) {

            case "C1":

                magicalCardGameModel.firstShuffle[0][0] = magicalCardGameModel.cardList[0][1];
                magicalCardGameModel.firstShuffle[0][1] = magicalCardGameModel.cardList[1][1];
                magicalCardGameModel.firstShuffle[0][2] = magicalCardGameModel.cardList[2][1];

                magicalCardGameModel.firstShuffle[1][0] = magicalCardGameModel.cardList[0][0];
                magicalCardGameModel.firstShuffle[1][1] = magicalCardGameModel.cardList[1][0];
                magicalCardGameModel.firstShuffle[1][2] = magicalCardGameModel.cardList[2][0];

                magicalCardGameModel.firstShuffle[2][0] = magicalCardGameModel.cardList[0][2];
                magicalCardGameModel.firstShuffle[2][1] = magicalCardGameModel.cardList[1][2];
                magicalCardGameModel.firstShuffle[2][2] = magicalCardGameModel.cardList[2][2];

                break;
            case "C2":

                magicalCardGameModel.firstShuffle[0][0] = magicalCardGameModel.cardList[0][0];
                magicalCardGameModel.firstShuffle[0][1] = magicalCardGameModel.cardList[1][0];
                magicalCardGameModel.firstShuffle[0][2] = magicalCardGameModel.cardList[2][0];

                magicalCardGameModel.firstShuffle[1][0] = magicalCardGameModel.cardList[0][1];
                magicalCardGameModel.firstShuffle[1][1] = magicalCardGameModel.cardList[1][1];
                magicalCardGameModel.firstShuffle[1][2] = magicalCardGameModel.cardList[2][1];

                magicalCardGameModel.firstShuffle[2][0] = magicalCardGameModel.cardList[0][2];
                magicalCardGameModel.firstShuffle[2][1] = magicalCardGameModel.cardList[1][2];
                magicalCardGameModel.firstShuffle[2][2] = magicalCardGameModel.cardList[2][2];
                break;
            case "C3":

                magicalCardGameModel.firstShuffle[0][0] = magicalCardGameModel.cardList[0][1];
                magicalCardGameModel.firstShuffle[0][1] = magicalCardGameModel.cardList[1][1];
                magicalCardGameModel.firstShuffle[0][2] = magicalCardGameModel.cardList[2][1];

                magicalCardGameModel.firstShuffle[1][0] = magicalCardGameModel.cardList[0][2];
                magicalCardGameModel.firstShuffle[1][1] = magicalCardGameModel.cardList[1][2];
                magicalCardGameModel.firstShuffle[1][2] = magicalCardGameModel.cardList[2][2];

                magicalCardGameModel.firstShuffle[2][0] = magicalCardGameModel.cardList[0][0];
                magicalCardGameModel.firstShuffle[2][1] = magicalCardGameModel.cardList[1][0];
                magicalCardGameModel.firstShuffle[2][2] = magicalCardGameModel.cardList[2][0];
                break;
            default:
                break;
        }

        return magicalCardGameModel.firstShuffle;
    }

    @Override
    public String[][] getSecShuffleResult(MagicalCardGameModel magicalCardGameModel) {

        magicalCardGameModel.secShuffle = magicalCardGameModel.firstShuffle;

        switch (magicalCardGameModel.secShuffleColPos) {

            case "C1":

                magicalCardGameModel.secShuffle[0][0] = magicalCardGameModel.firstShuffle[0][1];
                magicalCardGameModel.secShuffle[0][1] = magicalCardGameModel.firstShuffle[1][1];
                magicalCardGameModel.secShuffle[0][2] = magicalCardGameModel.firstShuffle[2][1];

                magicalCardGameModel.secShuffle[1][0] = magicalCardGameModel.firstShuffle[0][0];
                magicalCardGameModel.secShuffle[1][1] = magicalCardGameModel.firstShuffle[1][0];
                magicalCardGameModel.secShuffle[1][2] = magicalCardGameModel.firstShuffle[2][0];

                magicalCardGameModel.secShuffle[2][0] = magicalCardGameModel.firstShuffle[0][2];
                magicalCardGameModel.secShuffle[2][1] = magicalCardGameModel.firstShuffle[1][2];
                magicalCardGameModel.secShuffle[2][2] = magicalCardGameModel.firstShuffle[2][2];

                break;
            case "C2":

                magicalCardGameModel.secShuffle[0][0] = magicalCardGameModel.firstShuffle[0][0];
                magicalCardGameModel.secShuffle[0][1] = magicalCardGameModel.firstShuffle[1][0];
                magicalCardGameModel.secShuffle[0][2] = magicalCardGameModel.firstShuffle[2][0];

                magicalCardGameModel.secShuffle[1][0] = magicalCardGameModel.firstShuffle[0][1];
                magicalCardGameModel.secShuffle[1][1] = magicalCardGameModel.firstShuffle[1][1];
                magicalCardGameModel.secShuffle[1][2] = magicalCardGameModel.firstShuffle[2][1];

                magicalCardGameModel.secShuffle[2][0] = magicalCardGameModel.firstShuffle[0][2];
                magicalCardGameModel.secShuffle[2][1] = magicalCardGameModel.firstShuffle[1][2];
                magicalCardGameModel.secShuffle[2][2] = magicalCardGameModel.firstShuffle[2][2];
                break;
            case "C3":

                magicalCardGameModel.secShuffle[0][0] = magicalCardGameModel.firstShuffle[0][1];
                magicalCardGameModel.secShuffle[0][1] = magicalCardGameModel.firstShuffle[1][1];
                magicalCardGameModel.secShuffle[0][2] = magicalCardGameModel.firstShuffle[2][1];

                magicalCardGameModel.secShuffle[1][0] = magicalCardGameModel.firstShuffle[0][2];
                magicalCardGameModel.secShuffle[1][1] = magicalCardGameModel.firstShuffle[1][2];
                magicalCardGameModel.secShuffle[1][2] = magicalCardGameModel.firstShuffle[2][2];

                magicalCardGameModel.secShuffle[2][0] = magicalCardGameModel.firstShuffle[0][0];
                magicalCardGameModel.secShuffle[2][1] = magicalCardGameModel.firstShuffle[1][0];
                magicalCardGameModel.secShuffle[2][2] = magicalCardGameModel.firstShuffle[2][0];
                break;
            default:
                break;
        }

        return magicalCardGameModel.secShuffle;
    }

    @Override
    public String getFinalResult(MagicalCardGameModel magicalCardGameModel) {

        magicalCardGameModel.guessedCard = magicalCardGameModel.secShuffle[1][1];
        return magicalCardGameModel.guessedCard;
    }

}
