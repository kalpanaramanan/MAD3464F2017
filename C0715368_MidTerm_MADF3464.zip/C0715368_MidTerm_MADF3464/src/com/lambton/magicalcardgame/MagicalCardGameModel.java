/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lambton.magicalcardgame;

/**
 *
 * @author Kalpana Ramanan
 */
public class MagicalCardGameModel {

    String firstShuffleColPos;
    String secShuffleColPos;
    String[][] cardList = null;
    String[][] firstShuffle = null;
    String[][] secShuffle = null;
    String guessedCard;    
}
