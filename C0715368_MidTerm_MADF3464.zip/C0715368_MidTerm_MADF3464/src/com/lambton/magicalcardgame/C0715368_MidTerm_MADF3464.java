/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lambton.magicalcardgame;


/**
 *
 * @author Kalpana Ramanan
 */
public class C0715368_MidTerm_MADF3464 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        MagicalCardGameModel magicalCardGameModel = new MagicalCardGameModel();
        magicalCardGameModel.cardList = new String[][]{{"A", "4", "3"},
        {"K", "7", "2"},
        {"5", "9", "8"}
        };
        MagicalCardGameCalculator magicalCardGameCalculator = new MagicalCardGameCalculator();

        System.out.println(" Original Matrix : {");
        for (int rows = 0; rows < magicalCardGameModel.cardList.length; rows++) {
            System.out.print(" { " + magicalCardGameModel.cardList[rows][0] + " ");
            for (int cols = 1; cols < magicalCardGameModel.cardList[rows].length; cols++) {
                System.out.print(magicalCardGameModel.cardList[rows][cols] + " ");
            }
            System.out.println("},");
        }
        System.out.println(" }");

        magicalCardGameModel.firstShuffleColPos = "C2";
        String firstShuffledMatrix[][] = magicalCardGameCalculator.getFirstShuffleResult(magicalCardGameModel);
        

        System.out.println(" First Shuffled Matrix : {");
        for (int rows = 0; rows < firstShuffledMatrix.length; rows++) {
            System.out.print(" { " + firstShuffledMatrix[rows][0] + " ");
            for (int cols = 1; cols < firstShuffledMatrix[rows].length; cols++) {
                System.out.print(firstShuffledMatrix[rows][cols] + " ");
            }
            System.out.println("},");
        }
        System.out.println(" }");

        magicalCardGameModel.secShuffleColPos = "C3";
        String secondShuffledMatrix[][] = magicalCardGameCalculator.getSecShuffleResult(magicalCardGameModel);
        

        System.out.println(" Second Shuffled Matrix : {");
        for (int rows = 0; rows < secondShuffledMatrix.length; rows++) {
            System.out.print(" { " + firstShuffledMatrix[rows][0] + " ");
            for (int cols = 1; cols < secondShuffledMatrix[rows].length; cols++) {
                System.out.print(secondShuffledMatrix[rows][cols] + " ");
            }
            System.out.println("},");
        }
        System.out.println(" }");
        
      
        System.out.println("Your Guessed Card is :"+magicalCardGameCalculator.getFinalResult(magicalCardGameModel));
    }
}
