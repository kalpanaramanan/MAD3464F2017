/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lambton.finalproject.main;

import com.lambton.finalproject.logic.EmployeeImpl;
import com.lambton.finalproject.model.Car;
import com.lambton.finalproject.model.CommissionBasedPartTime;
import com.lambton.finalproject.model.Employee;
import com.lambton.finalproject.model.FixedBasedPartTime;
import com.lambton.finalproject.model.FullTime;
import com.lambton.finalproject.model.MotorCycle;

/**
 *
 * @author Kalpana Ramanan
 */
public class FinalProject_MADF3464 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        double totalPayroll = 0d;

        // FIRST EMPLOYEE
        MotorCycle motorCycle = new MotorCycle("1", "Hondo", "s4546", "1", "Motorcycle");
        Employee employee = new Employee(1, "Kalpana", 26, motorCycle);
        CommissionBasedPartTime commissionBasedPartTime = new CommissionBasedPartTime(20, 30, 10, employee.getEmployeeNo(), employee.getEmployeeName(), 0, motorCycle);

        Car car = new Car("1", "Hondo", "s4546", "2", "Car");
        Employee employee1 = new Employee(2, "Saiii", 27, car);
        FixedBasedPartTime fixedBasedPartTime = new FixedBasedPartTime(40, 50, 60, employee.getEmployeeNo(), employee.getEmployeeName(), 0, car);

        EmployeeImpl employeeImpl = new EmployeeImpl();
        Employee arrayEmployee[] = new Employee[4];
        arrayEmployee[0] = employee;
        arrayEmployee[1] = commissionBasedPartTime;
        arrayEmployee[2] = employee1;
        arrayEmployee[3] = fixedBasedPartTime;

        for (Employee arrayEmployee1 : arrayEmployee) {
            if (arrayEmployee1.getClass() == Employee.class) {
                Employee e = (Employee) arrayEmployee1;
                System.out.println(e.toString());
                System.out.println(employeeImpl.calculateBirthYear(e));
            }
            if (arrayEmployee1 instanceof CommissionBasedPartTime) {
                CommissionBasedPartTime e = (CommissionBasedPartTime) arrayEmployee1;
                System.out.println(e.toString());
            }
            if (arrayEmployee1 instanceof FixedBasedPartTime) {
                FixedBasedPartTime e = (FixedBasedPartTime) arrayEmployee1;
                System.out.println(e.toString());
            }
        }
        //PAYROLL
        // System.out.println("\nTOTAL PAYROLL : " + totalPayroll + " Canadian Dollars");
    }

}
