/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArrayAndArrayList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Kalpana Ramanan
 */
public class ArrayListExample {

    public static void main(String[] args) {
        int a[] = {10, 30, 20, 60, 40, 50};
        System.out.println("Unsorted Array: " + Arrays.toString(a));
        Arrays.sort(a);
        System.out.println("Sorted Array: " + Arrays.toString(a));
        String str[] = {"HelloA", "Hello", "helloA", "helloB", "helloc", "HelloC"};
        System.out.println("Unsorted Array String: " + Arrays.toString(str));
        Arrays.sort(str);
        System.out.println("Unsorted Array String: " + Arrays.toString(str));

        List<String> arrayList = new ArrayList<>();
        arrayList.add("A");
        arrayList.add("B");
        arrayList.add("C");
        arrayList.add("D");

        System.out.println("ArrayList Size " + arrayList.size());

        Movie movie1 = new Movie(1, "Tinker Bell");
        Movie movie2 = new Movie(2, "Enchanted");
        Movie movie3 = new Movie(3, "Perter Pan");
        List<Movie> arrayListMovie = new ArrayList<>();
        arrayListMovie.add(movie1);
        arrayListMovie.add(movie2);
        arrayListMovie.add(movie3);

        Movie m = arrayListMovie.get(0);
        System.out.println(m.toString());
        System.out.println("**************************** ");
        arrayListMovie.forEach((arrayListMovie1) -> {
            System.out.println("Movie Id: " + arrayListMovie1.getMovieId() + " Movie Title: " + arrayListMovie1.getMovieTitle());
        });
        Movie movie4 = new Movie(4, "Thor");
        arrayListMovie.add(3, movie4);

        System.out.println("**************************** ");

        for (Movie arrayListMovie1 : arrayListMovie) {
            System.out.println("Movie Id: " + arrayListMovie1.getMovieId() + " Movie Title: " + arrayListMovie1.getMovieTitle());
        }
        System.out.println("**************************** ");

    }
}
