/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NumericAndCommentLineArguments;

/**
 *
 * @author Kalpana Ramanan
 */
public class ArthimeticMain {

    public static void main(String[] args) {

        if (args.length != 3) {
            System.out.println("Enter correct number  ");
        } else {
            int a = Integer.parseInt(args[1]);
            int b = Integer.parseInt(args[2]);
            char operand = args[0].charAt(0);
            Arthimetic arthimetic = new Arthimetic();

            switch (operand) {
                case '+':
                    System.out.println("Addition: " + arthimetic.add(a, b));
                    break;
                case '-':
                    System.out.println("Subtraction: " + arthimetic.sub(a, b));
                    break;
                case '*':
                    System.out.println("Multiplocation: " + arthimetic.mul(a, b));
                    break;
                case '/':
                    System.out.println("Division: " + arthimetic.div(a, b));
                    break;
                case '%':
                    System.out.println("Modulo:" + arthimetic.mod(a, b));
                    break;
            }
        }
    }
}
