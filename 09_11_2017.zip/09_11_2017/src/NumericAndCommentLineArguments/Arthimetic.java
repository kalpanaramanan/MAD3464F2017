/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NumericAndCommentLineArguments;

/**
 *
 * @author Kalpana Ramanan
 */
public class Arthimetic {

    static int add(int valueA, int valueB) {
        return valueA + valueB;
    }

    static int sub(int valueA, int valueB) {
        return valueA - valueB;
    }

    static int mul(int valueA, int valueB) {
        return valueA * valueB;
    }

    static int div(int valueA, int valueB) {
        return valueA / valueB;
    }
    
    static int mod(int valueA, int valueB) {
        return valueA % valueB;
    }
    
}
