/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NumericAndCommentLineArguments;

import java.text.DecimalFormat;

/**
 *
 * @author macstudent
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int a = 10;
        int b = a;
        long c = 100;
        a = (int) c; // Exclipit conversion

        short a1 = 10;
        short b1 = 20;
        short c1 = a1;

        Short d = (short) (a1 * b1); //Exclipit conversion for short value

        int a2 = 23;
        int b2 = 5;
        float c2 = (float) a2 / b2;
        System.out.println(" value of c2 :" + c2);

        DecimalFormat fmt = new DecimalFormat("#.##"); // Decimal Format Conversion
        System.out.println(fmt.format(445.887));

        char ch = 65;
        System.out.println("Character Value for the numberic " + ch + ":" + ch); 

        int chN = 'A';
        System.out.println("Number Value for the Aplhabet " + chN + " :" + chN);
        
        
        String aStr = "Hello";
        String bStr = "\bHello".trim();
       
        if (aStr.equals(bStr)){
            System.out.println("Equal");
        }else{
            System.out.println("Not-Equal");
        }
        System.out.println("String Value of A:"+aStr + " String Value of B:"+bStr);
        
        Integer in = new Integer("12");
        System.out.println(" Interger Value:"+in);
        
        System.out.println("String Value : "+ String.valueOf(12));
        
        Integer i1 = 100;
        int i2 = i1;
        System.out.println("Value of i1: "+ i1);
        System.out.println("Value of i2 : "+ i2); // Boxing and UnBoxing
        
        Integer i3 = new Integer(20);// 20 is casted to Integer it is example of Boxing
        System.out.println("Value of i1: "+ i3.longValue());
        
        
    }

}
