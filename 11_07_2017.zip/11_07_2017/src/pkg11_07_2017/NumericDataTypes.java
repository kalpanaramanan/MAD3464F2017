/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_07_2017;

/**
 *
 * @author Kalpana Ramanan
 */
public class NumericDataTypes {

    static int x;
    static String fName;

    public static void main(String[] args) {
        int a = 0;
        float b = 11.9F;
        int c = 5____________2;
        int $ = 10;
        String name = "Hello";
        System.out.println(" Value of a " + a);
        System.out.println(" Value of b " + b);
        System.out.println(" Value of c " + c);
        System.out.println(" Value of $$$ " + $);
        System.out.println(" x :" + x);
        System.out.println("Name : " + name);
        System.out.println("name.length() :" + name.length());
        System.out.println("fName is :" + fName);

        int a1 = 10, a2 = 10;
        System.out.println(" Value of a1 :" + a1);
        System.out.println(" Value of a2 :" + a2);

        String s1 = "Hello", s2 = "Hello";
        System.out.println(" Value of S1 :" + s1);
        System.out.println(" Value of S2 :" + s2);

        String s3 = new String("Hello");

        if (s1.equals(s3)) {
            System.out.println("s1 == s3");
        } else {
            System.out.println("s1 != s3");
        }
          if (s1 == s3) {
            System.out.println("s1 == s3");
        } else {
            System.out.println("s1 != s3");
        }
    }

    public void main() {
        //System.out.println(" a :"+ a);
    }
}
