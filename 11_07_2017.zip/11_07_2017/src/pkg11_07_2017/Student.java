/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_07_2017;

/**
 *
 * @author Kalpana Ramanan
 */
public class Student {

    int studentID;
    String studentName;
    int marks[];
    float total;
    float average;
    String result;

    public Student() {
        this.studentID = 0;
        this.studentName = null;
        this.marks = new int[5];
        this.total = 0.0f;
        this.average = 0.0f;
        this.result = null;
    }

    public Student(int studentID, String studentName, int[] marks) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.marks = marks;
      
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public int[] getMarks() {
        return marks;
    }

    public void setMarks(int[] marks) {
        this.marks = marks;
    }

    @Override
    public String toString() {
        return "Student{" + "studentID=" + studentID + ", studentName=" + studentName + ", total=" + total + ", marks=" + marks + '}';
    }

    void printStudentDetails() {
        System.out.println(" Student Id :" + this.studentID);
        System.out.println(" Student Name :" + this.studentName);
        for (int i = 0; i < marks.length; i++) {
            System.out.println(" Student Marks of  " + (i + 1) + ":" + this.marks[i]);
        }
        caculateTotal();
        System.out.println(" Student Total Marks :" + this.total);
    }
    
    void printStudentDetail() {
        System.out.println(" Student Id :" + this.getStudentID());
        System.out.println(" Student Name :" + this.getStudentName());
        for (int i = 0; i < marks.length; i++) {
            System.out.println(" Student Marks of  " + (i + 1) + ":" + this.getMarks()[i]);
        }
        caculateTotal();
        calcuateResult();
        System.out.println(" Student Total Marks :" + this.getTotal());
        System.out.println(" Student Average  :" + this.average);
        System.out.println(" Student Result :" + this.result);
    }
    
    private void caculateTotal(){
        for (int i = 0; i < this.marks.length; i++) {
            this.total += this.marks[i];
        }
    }
    
    private void calcuateResult(){
        this.average = this.total/5 ;
        if (this.average >= 95 ){
            this.result = "A+";
        }else if (this.average >= 85 && this.average < 95){
            this.result = "A";
        } else if (this.average >= 75 && this.average < 85){
            this.result = "B+";
        }else if (this.average >= 65 && this.average < 75){
            this.result = "B";
        }else if (this.average >= 55 && this.average < 65){
            this.result = "C+";
        }else if (this.average >= 50 && this.average < 55){
            this.result = "C";
        }else if (this.average >= 45 && this.average < 50){
            this.result = "D+";
        }else if (this.average < 45){
            this.result = "FAIL";
        }
    }
}
