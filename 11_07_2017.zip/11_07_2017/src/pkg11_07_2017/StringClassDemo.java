/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_07_2017;

/**
 *
 * @author Kalpana Ramanan
 */
public class StringClassDemo {

    public static void main(String[] args) {
        String name = "Welcome to Canada Kalpana";
        char searchElement = 'a';
        int count =  searchAElement(name,searchElement);
        System.out.println(" Count of Element A :"+count);
    }
    
   static int searchAElement(String name, char searchElement){
       int sum = 0;
        char[] charB = name.toCharArray();

        for (int i = 0; i < charB.length; i++) {
            System.out.println(charB[i]);
            if (charB[i] == searchElement) {
                sum += 1;
            }

        }
        return sum;
    }
}

