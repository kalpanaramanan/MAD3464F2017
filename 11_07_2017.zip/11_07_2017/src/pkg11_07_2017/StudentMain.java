/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_07_2017;

/**
 *
 * @author Kalpana Ramanan
 */
public class StudentMain {

    public static void main(String[] args) {
        Student student = new Student(1, "Kalpana", new int[]{10,10,10,50,50});
        System.out.println("*********************************");
        System.out.println("          STUDENT DETAILS");
        System.out.println("*********************************");
        student.printStudentDetail();
    }
}
