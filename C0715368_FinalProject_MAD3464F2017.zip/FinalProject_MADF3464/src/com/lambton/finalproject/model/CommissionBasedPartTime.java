/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lambton.finalproject.model;

/**
 *
 * @author Kalpana Ramanan
 */
public class CommissionBasedPartTime extends PartTime {

    private double commissionPercentage;

    public double getCommissionPercentage() {
        return commissionPercentage;
    }

    public void setCommissionPercentage(double commissionPercentage) {
        this.commissionPercentage = commissionPercentage;
    }

    public CommissionBasedPartTime(double commissionPercentage, double rate, double noOfHoursWorked) {
        super(rate, noOfHoursWorked);
        this.commissionPercentage = commissionPercentage;
    }

    public CommissionBasedPartTime(double commissionPercentage, double rate, double noOfHoursWorked, int employeeNo, String employeeName, int age, Vehicle vehicle) {
        super(rate, noOfHoursWorked, employeeNo, employeeName, age, vehicle);
        this.commissionPercentage = commissionPercentage;
    }

    @Override
    public String toString() {

        String str = ("Employee is Part Time / Commissioned " + "\n"
                + " * Rate : " + getRate() + "\n"
                + " * Hours Worked : " + getNoOfHoursWorked() + "\n"
                + " * Commission : " + getCommissionPercentage() + "\n"
                + " * Earnings: " + ((getRate() * getNoOfHoursWorked()) + ((getCommissionPercentage() / 100) * (getRate() * getNoOfHoursWorked())))
                + "(" + (getRate() * getNoOfHoursWorked()) + " + " + this.getCommissionPercentage() + "% of " + (getRate() * getNoOfHoursWorked()) + ")"
                + "\n");

        return str;

    }

}
