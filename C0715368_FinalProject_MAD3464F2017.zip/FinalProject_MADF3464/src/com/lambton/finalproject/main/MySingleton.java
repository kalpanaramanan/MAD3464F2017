/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lambton.finalproject.main;

import com.lambton.finalproject.logic.CommissionBasedPartTimeImpl;
import com.lambton.finalproject.logic.EmployeeImpl;
import com.lambton.finalproject.logic.FixedBasedPartTimeImpl;
import com.lambton.finalproject.model.Car;
import com.lambton.finalproject.model.CommissionBasedPartTime;
import com.lambton.finalproject.model.Employee;
import com.lambton.finalproject.model.FixedBasedPartTime;
import com.lambton.finalproject.model.Intern;
import com.lambton.finalproject.model.MotorCycle;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 *
 * @author Kalpana Ramanan
 */
public class MySingleton {

    private static MySingleton obj;
    private final DecimalFormat formatter = new DecimalFormat("###,###,###");

    private MySingleton() {
    }

    public static MySingleton getMySingleton() {
        synchronized (MySingleton.class) {
            if (obj == null) {
                obj = new MySingleton();//instance will be created at request time
            }
        }
        return obj;
    }

    public void getEmployeeData() {
        ArrayList<Double> totalPayRollList = new ArrayList<>();

        // FIRST EMPLOYEE
       // MotorCycle motorCycle = new MotorCycle("1", "Hondo", "SE4546", "1", "Motorcycle");
        MotorCycle motorCycle = new MotorCycle();
        motorCycle.setMotorCycleNumber("1");
        motorCycle.setModel("Hondo");
        motorCycle.setBrand("SE4546");
        motorCycle.setVehicleNo("1");
        motorCycle.setVehicleType("Motorcycle");
        
        Employee employee = new Employee(1, "Kalpana Ramanan", 26, motorCycle);
        
        CommissionBasedPartTime commissionBasedPartTime = new CommissionBasedPartTime(20, 30, 10, employee.getEmployeeNo(), employee.getEmployeeName(), 0, motorCycle);

        CommissionBasedPartTimeImpl commissionBasedPartTimeImpl = new CommissionBasedPartTimeImpl();
        employee.setEarnings(commissionBasedPartTimeImpl.calculateCommissionBasedPartTime(commissionBasedPartTime));
        totalPayRollList.add(employee.getEarnings());

        // SECOND EMPLOYEE
        Car car = new Car("2", "TATA", "A4RT44", "2", "Car");
        Employee employee1 = new Employee(2, "Sai Praveen", 30, car);
        FixedBasedPartTime fixedBasedPartTime = new FixedBasedPartTime(40, 30, 10, employee1.getEmployeeNo(), employee1.getEmployeeName(), 0, car);
        FixedBasedPartTimeImpl fixedBasedPartTimeImpl = new FixedBasedPartTimeImpl();
        employee1.setEarnings(fixedBasedPartTimeImpl.calculateFixedBasedPartTime(fixedBasedPartTime));
        totalPayRollList.add(employee1.getEarnings());

        // THIRD EMPLOYEE
        Employee employee2 = new Employee(3, "Omika Balaji", 25, null);
        Intern intern = new Intern("Lambton College", employee2.getEmployeeNo(), employee2.getEmployeeName(), 0, null);
        employee2.setEarnings(1000d);
        totalPayRollList.add(employee2.getEarnings());

        EmployeeImpl employeeImpl = new EmployeeImpl();
        employee.setBirthyear(employeeImpl.calculateBirthYear(employee));
        employee1.setBirthyear(employeeImpl.calculateBirthYear(employee1));
        employee2.setBirthyear(employeeImpl.calculateBirthYear(employee2));

        ArrayList<Employee> arrayEmployee = new ArrayList<>();
        arrayEmployee.add(employee);
        arrayEmployee.add(commissionBasedPartTime);
        arrayEmployee.add(employee1);
        arrayEmployee.add(fixedBasedPartTime);
        arrayEmployee.add(employee2);
        arrayEmployee.add(intern);

        for (Employee arrayEmployee1 : arrayEmployee) {
            if (arrayEmployee1.getClass() == Employee.class) {
                Employee e = (Employee) arrayEmployee1;
                System.out.println(e.toString());
            }
            if (arrayEmployee1 instanceof CommissionBasedPartTime) {
                CommissionBasedPartTime e = (CommissionBasedPartTime) arrayEmployee1;
                System.out.println(e.toString());

            }
            if (arrayEmployee1 instanceof FixedBasedPartTime) {
                FixedBasedPartTime e = (FixedBasedPartTime) arrayEmployee1;
                System.out.println(e.toString());
            }

            if (arrayEmployee1 instanceof Intern) {
                Intern e = (Intern) arrayEmployee1;

                System.out.println(e.toString());
                System.out.println(" * Earnings : " + employeeImpl.calculateEarnings(e));
            }
        }

        //Calculate Total Earnings
        double totalPayrollSum = 0d;
        for (int i = 0; i < totalPayRollList.size(); i++) {
            totalPayrollSum += totalPayRollList.get(i);
        }

        //PAYROLL
        System.out.println("\nTOTAL PAYROLL : " + formatter.format(totalPayrollSum) + " Canadian Dollars");
    }

}
